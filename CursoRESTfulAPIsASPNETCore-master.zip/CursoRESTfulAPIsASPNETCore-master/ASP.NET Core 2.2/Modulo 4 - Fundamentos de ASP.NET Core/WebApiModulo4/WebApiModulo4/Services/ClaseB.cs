﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiModulo4.Services
{
    public class ClaseB : IClaseB
    {
        public void HacerAlgo()
        {
        }
    }

    public class ClaseB2 : IClaseB
    {
        public void HacerAlgo()
        {
        }
    }
}
